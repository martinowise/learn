export function sayHello() {
    console.log("Hallo von utils.js!");
}
