let currentTextPosition = 0;
let currentLevel = 0;
let errorCount = 0;
let wrongClickCount = 0;
let hasShownCorrectClickMessage = false;
let hasShownSkippedWordMessage = false;

// Tooltip-Funktionen importieren oder einbinden
// Normalerweise würde man hier importieren, aber für direktes Einbinden:
// import { showTooltip, hideTooltip } from './tooltip-utils.js';

function getRandomColor() {
    const colors = [
        '#ff4136', // red
        '#ffdc00', // yellow
        '#2ecc40', // green
        '#0074d9', // blue
        '#b10dc9', // purple
        '#ff851b', // orange
        '#7fdbff', // light blue
        '#f012be', // pink
        '#39cccc', // teal
        '#01ff70'  // lime
    ];
    return colors[Math.floor(Math.random() * colors.length)];
}

function updateLevelDisplay() {
    document.getElementById('current-level').textContent = currentLevel;
    const levelSettings = getLevelSettings(currentLevel);
    const codeElement = document.getElementById('level-code');
    if (levelSettings && levelSettings.secret) {
        codeElement.textContent = levelSettings.secret;
        codeElement.style.display = 'inline';
    } else {
        codeElement.style.display = 'none';
    }
}

function createConfetti(element, { 
    minCount = 5,      // Minimale Anzahl
    maxCount = 10,     // Maximale Anzahl
    duration = 0.5     // Dauer in Sekunden
} = {}) {
    const rect = element.getBoundingClientRect();
    const centerX = rect.left + (rect.width / 2);
    const centerY = rect.top + (rect.height / 2);

    // Zufällige Anzahl zwischen min und max
    const count = Math.floor(Math.random() * (maxCount - minCount + 1)) + minCount;

    for (let i = 0; i < count; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        
        // Zufällige Bewegung
        const angle = Math.random() * Math.PI; // Winkel für die Bewegung (nur nach oben: 0 bis π)
        const distance = 30 + Math.random() * 90; // Zufällige Distanz zwischen 30 und 120 Pixeln
        const endX = Math.cos(angle) * distance;
        const endY = -Math.sin(angle) * distance; // Negativ für Bewegung nach oben
        
        // Zufällige Rotation zwischen 180 und 720 Grad
        const rotation = (180 + Math.random() * 540) + 'deg';
        
        // Zufällige Verzögerung
        const delay = Math.random() * 0.1; // 0 bis 0.1 Sekunden

        // Stil setzen
        confetti.style.left = `${centerX}px`;
        confetti.style.top = `${centerY}px`;
        confetti.style.background = getRandomColor();
        confetti.style.setProperty('--end-x', `${endX}px`);
        confetti.style.setProperty('--end-y', `${endY}px`);
        confetti.style.setProperty('--rotation', rotation);
        confetti.style.animation = `confetti-fall ${duration}s ease-out ${delay}s forwards`;

        document.body.appendChild(confetti);

        // Aufräumen nach Animation
        confetti.addEventListener('animationend', () => confetti.remove());
    }
}

function showText() {
    const container = document.getElementById('game-container');
    container.innerHTML = '';
    errorCount = 0;
    
    // Hole die korrekten Level-Settings für die Satzanzahl
    const levelSettings = getLevelSettings(currentLevel);
    const numberOfSentences = levelSettings.sentences;
    
    const correctText = getText(currentTextPosition, numberOfSentences);
    const incorrectText = addErrors(correctText, currentLevel);
    
    const incorrectWords = generateWordList(incorrectText);
    const correctWords = generateWordList(correctText);
    
    incorrectWords.forEach((word, index) => {
        const span = document.createElement('span');
        span.textContent = word;
        
        if (!/^[.!?,\s]+$/.test(word)) {
            span.className = 'word';
            span.dataset.checked = 'false';
            span.dataset.correctWord = correctWords[index];
            span.dataset.wasModified = (word !== correctWords[index]).toString();
            
            span.onclick = function() {
                handleWordClick(this);
            };
        } else {
            span.className = 'punctuation';
        }
        
        container.appendChild(span);
    });

    addFinishButton(container);
}

function handleWordClick(wordElement) {
    console.log('handleWordClick called');

    if (wordElement.dataset.checked === 'true') return;
    
    const container = document.getElementById('game-container');
    const wordElements = Array.from(container.getElementsByClassName('word'));
    const currentIndex = wordElements.indexOf(wordElement);
    
    // Prüfe ob es unbehandelte fehlerhafte Wörter vor dem aktuellen Wort gibt
    const hasUnhandledErrorsBefore = wordElements.some((word, index) => {
        return index < currentIndex && 
               word.dataset.checked === 'false' && 
               word.dataset.wasModified === 'true';
    });

    if (hasUnhandledErrorsBefore) {
        // Statt Modal: Zeige Tooltip mit Warnung
        showTooltip(
            wordElement,
            "⚠️ Tipp: Bearbeite die Wörter der Reihe nach - es gibt noch Fehler vor diesem Wort!",
            'info',
            { duration: 3000 }
        );
        hasShownSkippedWordMessage = true;
        return;
    }
    
    // Auto-check vorherige Wörter
    for (let i = 0; i < wordElements.length; i++) {
        const currentElement = wordElements[i];
        if (currentElement === wordElement) break;
        if (currentElement.dataset.checked === 'false') {
            autoCheckWord(currentElement);
        }
    }
    
    // Prüfe angeklicktes Wort
    const wasModified = wordElement.dataset.wasModified === 'true';
    wordElement.dataset.checked = 'true';
    console.log('111');
    
    if (wasModified) {
        // Korrekter Klick
        wordElement.textContent = wordElement.dataset.correctWord;
        console.log('korrekt!');
        wordElement.className = 'word correct';
        
        // Statt Modal: Zeige Tooltip mit Erfolgsmeldung
        showTooltip(
            wordElement, 
            "🎯 Super! Du hast einen Fehler gefunden!", 
            'success'
        );
        
        createConfetti(wordElement, { 
            minCount: 3, 
            maxCount: 10, 
            duration: 0.5 
        });

        if (!hasShownCorrectClickMessage) {
            hasShownCorrectClickMessage = true;
        }
    } else {
        // Falscher Klick
        wordElement.className = 'word incorrect';
        errorCount++;
        
        // Statt Modal: Zeige Tooltip mit Fehlermeldung
        const messages = [
            "😅 Ups! Dieses Wort war eigentlich richtig geschrieben!",
            "🤔 Nicht jedes Wort enthält einen Fehler!",
            "💡 Klicke nur auf Wörter, die falsch geschrieben sind!"
        ];
        
        showTooltip(
            wordElement,
            messages[Math.min(wrongClickCount, messages.length - 1)],
            'error'
        );
        
        wrongClickCount++;
    }
}

function autoCheckWord(wordElement) {
    if (wordElement.dataset.checked === 'true' || 
        wordElement.className === 'punctuation' || 
        wordElement.textContent === '🏁 Fertig!') return;
    
    const wasModified = wordElement.dataset.wasModified === 'true';
    wordElement.dataset.checked = 'true';
    
    if (!wasModified) {
        // Wort war korrekt
        wordElement.className = 'word correct';
        
        // Optional: Tooltip für auto-check
        showTooltip(wordElement, "✓ Richtig!", 'success', { 
            duration: 1000, 
            closeOthers: false 
        });
    } else {
        // Wort hatte einen Fehler - wurde übersehen
        wordElement.textContent = wordElement.dataset.correctWord;
        wordElement.className = 'word incorrect';
        
        // Optional: Tooltip für übersehenen Fehler
        showTooltip(wordElement, "❌ Hier war ein Fehler!", 'error', { 
            duration: 1000, 
            closeOthers: false 
        });
        
        errorCount++;
    }
}

function handleFinishClick(button, container) {
    if (button.textContent === '🏁 Fertig!') {
        const wordElements = Array.from(container.getElementsByClassName('word'));
        
        // Zähle unbehandelte fehlerhafte Wörter
        const uncheckedErrors = wordElements.filter(word => {
            return word !== button && 
                   word.dataset.checked === 'false' && 
                   word.dataset.wasModified === 'true';
        }).length;

        if (uncheckedErrors > 0) {
            // Statt Modal: Tooltip am Fertig-Button
            showTooltip(button, getUncheckedErrorMessage(uncheckedErrors), 'info', {
                duration: 3000
            });
            return;
        }

        // Wenn keine unbehandelten Fehler, prüfe alle verbleibenden Wörter
        wordElements.forEach(word => {
            if (word === button) return;
            if (word.dataset.checked === 'false') {
                autoCheckWord(word);
            }
        });

        const message = getFinishMessage(errorCount);
        if (errorCount == 0) {
            createConfetti(button, { 
                minCount: 120, 
                maxCount: 230, 
                duration: 0.8 
            });
        }
        if (errorCount == 1) {
            createConfetti(button, { 
                minCount: 60, 
                maxCount: 80, 
                duration: 0.8 
            });
        }

        const feedbackText = document.createElement('span');
        feedbackText.textContent = ' ' + message;
        feedbackText.style.marginLeft = '10px';
        
        button.textContent = '➡️ Nächster Versuch!';
        if (errorCount <=1) {
            x = currentLevel + 1;
            button.textContent = '➡️ Weiter zu Level ' + x + '!!';
        }
        button.className = 'word';
        
        button.parentNode.appendChild(feedbackText);
    } else {
        const currentSettings = getLevelSettings(currentLevel);
        currentTextPosition += currentSettings.sentences;
        if (errorCount <=1) {
            currentLevel = currentLevel + 1;
            updateLevelDisplay();
        }
        button.textContent = '🏁 Fertig!';
        showText();
    }
}

function addFinishButton(container) {
    const feedbackContainer = document.createElement('div');
    feedbackContainer.style.marginTop = '20px';
    
    const finishButton = document.createElement('span');
    finishButton.textContent = '🏁 Fertig!';
    finishButton.className = 'word';
    finishButton.style.cursor = 'pointer';
    finishButton.onclick = function() {
        handleFinishClick(this, container);
    };
    
    feedbackContainer.appendChild(finishButton);
    container.appendChild(feedbackContainer);
}

let currentGameId = 'scifi';

function getCurrentGame() {
    return games[currentGameId];
}

function getText(position, numberOfSentences) {
    let sentences = getCurrentGame().story.slice(position, position + numberOfSentences);
    return sentences.join(" ");
}

function getLevelSettings(level) {
    let levelSettings = getCurrentGame().levels.find(config => config.level === level);
    if (!levelSettings) {
        // Fallback auf höchstes Level wenn Level nicht gefunden
        levelSettings = getCurrentGame().levels.find(config => 
            config.level === Math.max(...getCurrentGame().levels.map(c => c.level))
        );
    }
    return levelSettings;
}

function newGame() {
    // Aktuelle Spiel-ID aus dem Selector holen
    currentGameId = document.getElementById('game-selector').value;
    
    currentTextPosition = 0;
    currentLevel = 0;
    errorCount = 0;
    wrongClickCount = 0;
    hasShownCorrectClickMessage = false;
    
    showText();
    updateLevelDisplay();
}

// Event-Listener für Spiel-Auswahl
document.addEventListener('DOMContentLoaded', function() {
    const selector = document.getElementById('game-selector');
    selector.addEventListener('change', function() {
        if (confirm('Möchtest du wirklich das Spiel wechseln? Der aktuelle Fortschritt geht verloren.')) {
            newGame();
        } else {
            // Zurück zur vorherigen Auswahl
            selector.value = currentGameId;
        }
    });
    showText();
});